CREATE TRIGGER set_default_player_name
    AFTER INSERT
    ON players
BEGIN
    UPDATE players SET name = 'Player' || ID WHERE name IS NULL;
end;

